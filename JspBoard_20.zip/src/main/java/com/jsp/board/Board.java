package com.jsp.board;

public class Board {
	public static final int LIST_AMOUNT = 5; //글 리스트에 보이는 글 개수
	public static final int PAGE_LIKE_AMOUNT = 3; 
	
}
