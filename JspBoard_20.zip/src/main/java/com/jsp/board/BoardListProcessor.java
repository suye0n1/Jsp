package com.jsp.board;


import java.util.ArrayList;

import com.db.Dao;
import com.db.Dto;

public class BoardListProcessor {
	private Dao dao;	
	public ArrayList<Dto> posts;
	public int totalPage = 0;
	public int currentPage = 0;
	
	//페이징 블럭
	int totalBlock = 0;
	int currentBlockNo = 0;
	int blockStartNo = 0;
	int blockEndNo = 0;
	int prevPage = 0;
	int nextPage = 0;
	boolean hasPrev = true;
	boolean hasNext = true;

	//request.getParameter 때문에 currentPage를 String으로 선언??
	//검색(3)매개변수 word 생성
	public BoardListProcessor(Dao dao, String currentPage, String word) {
		super();
		this.dao = dao;
		this.currentPage = Integer.parseInt(currentPage);
		if(word==null) {	//단어가 null이면
			this.totalPage = getPageCount(); 
			getList();			
		}	else {
			this.totalPage = getSearchPageCount(word);
			getList(word);			
		}
		
		totalBlock = (int)Math.ceil((double)totalPage / Board.PAGE_LIKE_AMOUNT);
		currentBlockNo = (int)Math.ceil((double)this.currentPage / Board.PAGE_LIKE_AMOUNT);
		blockStartNo = (currentBlockNo - 1) * Board.PAGE_LIKE_AMOUNT + 1;
		blockEndNo = currentBlockNo * Board.PAGE_LIKE_AMOUNT;
		
		//?????
		if(blockEndNo > totalPage) {
			blockEndNo = totalPage;
		}
		
		if(currentBlockNo == 1) {
			hasPrev = false;
		}	else {
			hasPrev = true;
			prevPage = (currentBlockNo - 1) * Board.PAGE_LIKE_AMOUNT;
		}
		
		if(currentBlockNo < totalBlock) {
			hasNext = true;
			nextPage = currentBlockNo * Board.PAGE_LIKE_AMOUNT + 1;
		}	else {
			hasNext = false;
		}
	}
	
	public void getList() {
		int startIndex = (currentPage-1)*Board.LIST_AMOUNT;
		posts = dao.selectList(startIndex);
	}
	
	//검색(4)-검색 리스트
	public void getList(String word) {
		//listSearch함수에서 page가 문자열이고 currentPage가 int형이기 때문에 문자열로 변환
		posts = dao.listSearch(word, currentPage+"");
	}
	
	//총 페이지 수 구하기
	public int getPageCount() {
		int totalPageCount = 0;
		int count = dao.getPostCount();
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		}	else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	//검색 총 페이지 수 구하기
	public int getSearchPageCount(String word) {
		int totalPageCount = 0;
		int count = dao.getSearchPostCount(word);
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		}	else {
			totalPageCount = count / Board.LIST_AMOUNT+ 1;
		}
		return totalPageCount;
		
	}
	
	//글 리스트 객체 얻는 함수
	public ArrayList<Dto> getPosts(){
		return posts;
	}
	
	//페이지 리스트들 출력
	public String getHtmlPageList() {
		String html = "";
		
		if(hasPrev) {
			html = html + String.format("<a href='/board_2/list?page=%d'>이전</a>",prevPage);
		}	
		
		
		for(int i=blockStartNo; i<=blockEndNo; i++) {
			html = html + String.format("<a href='/board_2/list?page=%d'>%d</a>&nbsp;&nbsp;", i,i);
		}
		
		if(hasNext) {
		html = html + String.format("<a href='/board_2/list?page=%d'>다음</a>",nextPage);
		}
		return html;
	}
	
}
