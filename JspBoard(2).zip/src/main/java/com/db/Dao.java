package com.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Da{

	//삭제
	//(int no)로 해주면 del.jsp에서 괄호 안에 숫자가 들어감ㅡ>dao.del(3);
	public void del(String no) {
		super.connect();
		connect();	//????
			String sql = String.format("delete from %s where num=%s"
					,Db.BOARD_2, no);
			super.update(sql);
			super.close();
			
	}
	
	//쓰기
	public void write(Dto d) {
		super.connect();
			String sql = String.format(
					"insert into %s (title,content,id) values ('%s','%s','%s');"
					,Db.BOARD_2, d.title,d.content,d.id);
			super.update(sql);
			super.close();
	}
	
	//읽기
	public Dto read(String no) {
		super.connect();
		Dto post = null;
		try {
			
			//sql 되는거 예문 아래에 복붙해두고 비교해서 작성하시고. (실무에선 혼남. 지울것)
//			select * from ps_board_free where b_no=4;
			String sql = String.format(
					"select * from %s where num=%s"
					,Db.BOARD_2, no);
			System.out.println("sql:"+sql);//todo
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			//post 뭐야 ㅡ> post에 저장하고 return해줌
			post = new Dto(
					rs.getString("num"),
					rs.getString("title"),
					rs.getString("id"),
					rs.getString("dt"),
					rs.getString("hits"),
					rs.getString("content"),
					rs.getString("re_text"),
					rs.getString("re_count"),
					rs.getString("ori_num")
					);
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}
	//목록
//	2.매개변수 넣기
	public ArrayList<Dto> list(String page) {
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			
			//3.시작인덱스 0
			//1page이면 0 2page이면 3 .....
			int startIndex = ((Integer.parseInt(page))-1)*Board.LIST_AMOUNT;
			//페이징처리
			//1.limit용법 사용	limit 3 ㅡ> 3개 가지고오기 /limit 0,3 0번째부터 3개 나오게하기
			String sql = String.format(
					"select * from %s limit %s,%s"
					,Db.BOARD_2,startIndex,Board.LIST_AMOUNT);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {				
				posts.add(new Dto(
						rs.getString("num"),
						rs.getString("title"),
						rs.getString("id"),
						rs.getString("dt"),
						rs.getString("hits"),
						rs.getString("content"),
						rs.getString("re_text"),
						rs.getString("re_count"),
						rs.getString("ori_num")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	//업데이트
	public void edit(Dto d,String no) {
		super.connect();
			String sql = String.format(
					"update %s set title='%s',content='%s' where num=%s"
					,Db.BOARD_2, d.title,d.content,no);
			super.update(sql);
			super.close();
			
	}
	
	//글 목록: 총 페이지
	public int getPostCount() {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("select count(*) from %s" , Db.BOARD_2);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		}  catch (Exception e) {
			e.printStackTrace();
		}
		super.close();	//[고정4,5]
		return count;
	}
	
	//글 목록: 페이지 당 개수
	public int getTotalPageCount() {
		int totalPageCount = 0;
		int count = getPostCount();
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		}else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	//글 리스트 검색
	public ArrayList<Dto> listSearch(String word, String page){
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1) * 3;
			
		String sql = String.format("select * from %s where title like '%%%s%%' limit %s,%s",Db.BOARD_2,word,startIndex,Board.LIST_AMOUNT);
		System.out.println("sql:"+sql);
		ResultSet rs = st.executeQuery(sql);
		while(rs.next()) {
			posts.add(new Dto(
					rs.getString("num"),
					rs.getString("title"),
					rs.getString("id"),
					rs.getString("dt"),
					rs.getString("hits"),
					rs.getString("content"),
					rs.getString("re_text"),
					rs.getString("re_count"),
					rs.getString("ori_num")
					));
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	//검색했을 때 전체 페이지 수
	public int getSearchPostCount(String word) {
		int count = 0;
		super.connect();
		try {
			String sql = String.format("select count(*) from %s where title like '%%%s%%'", Db.BOARD_2,word);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		}catch (Exception e) {
			e.printStackTrace();
		}
		super.close();	//[고정4,5]
		return count;
	}	

	//검색했을 때 페이지 당 개수
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		int count = getSearchPostCount(word);
		
		if(count % Board.LIST_AMOUNT == 0) {
			totalPageCount = count / Board.LIST_AMOUNT;
		}else {
			totalPageCount = count / Board.LIST_AMOUNT + 1;
		}
		return totalPageCount;
	}
	
	}

