package com.db;

import com.jsp.board.BoardListProcessor;

public class Service{
	Dao dao;
	
	public Service() {
		dao = new Dao();
	}
	public void del(String no) {
		dao.del(no);
	}
	public void write(Dto d) {
		dao.write(d);
	}
	public Dto read(String no) {
		return dao.read(no);
	}
	//list(4)함수 실행
	public BoardListProcessor list(String currentPage){
		if(currentPage == null) {	//currentPage가 null이면
			currentPage = "1";	//1페이지가 나오도록
		}
		//새로운 객체 생성
		//BoardListProcessor클래스에서 dao에 저장된 값과 currentPage에 저장된 값을 저장
		BoardListProcessor blp = new BoardListProcessor(dao,currentPage);
		return blp;
	}
	public void edit(Dto d, String no) {
		dao.edit(d, no);
	}
}
