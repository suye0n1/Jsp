package com.db;

public class Dto {
		public String num;         
		public String title;      
		public String id;         
		public String dt;   
		public String hits;        
		public String content;  
		public String re_text;  
		
		public String re_count;
		public String ori_num;
		
		public Dto(String title, String id, String content) {
			//부모클래스 생성자 호출
		//	super();
			this.title = title;
			this.id = id;
			this.content = content;
		}
		public Dto(String num, String title, String id, String dt, String hits, String content, String re_text,
				String re_count, String ori_num) {
		//	super();
			this.num = num;
			this.title = title;
			this.id = id;
			this.dt = dt;
			this.hits = hits;
			this.content = content;
			this.re_text = re_text;
			this.re_count = re_count;
			this.ori_num = ori_num;
		}
		public Dto(String title, String content) {
			super();
			this.title = title;
			this.content = content;
		}

}
