package com.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Dao extends Da{

	//삭제
	//(int no)로 해주면 del.jsp에서 괄호 안에 숫자가 들어감ㅡ>dao.del(3);
	public void del(String no) {
		super.connect();
		connect();	//????
			String sql = String.format("delete from %s where num=%s"
					,Db.BOARD_2, no);
			super.update(sql);
			super.close();
			
	}
	
	//쓰기
	public void write(Dto d) {
		super.connect();
			String sql = String.format(
					"insert into %s (title,content,id) values ('%s','%s','%s');"
					,Db.BOARD_2, d.title,d.content,d.id);
			super.update(sql);
			super.close();
	}
	
	//읽기
	public Dto read(String no) {
		super.connect();
		Dto post = null;
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);	// [고정-1]
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);	// [고정-2]			
			st=con.createStatement();	// [고정-3]
			
	
			//sql 되는거 예문 아래에 복붙해두고 비교해서 작성하시고. (실무에선 혼남. 지울것)
//			select * from ps_board_free where b_no=4;
			String sql = String.format(
					"select * from %s where num=%s"
					,Db.BOARD_2, no);
			System.out.println("sql:"+sql);//todo
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			//post 뭐야 ㅡ> post에 저장하고 return해줌
			post = new Dto(
					rs.getString("num"),
					rs.getString("title"),
					rs.getString("id"),
					rs.getString("dt"),
					rs.getString("hits"),
					rs.getString("content"),
					rs.getString("re_text"),
					rs.getString("re_count"),
					rs.getString("ori_num")
					);
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return post;
	}
	//목록
	public ArrayList<Dto> list() {
		super.connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			Class.forName(Db.DB_JDBC_DRIVER_PACKAGE_PATH);	// [고정-1]
			con = DriverManager.getConnection(Db.DB_URL, Db.DB_ID, Db.DB_PW);	// [고정-2]			
			st=con.createStatement();	// [고정-3]
			
			//여기에 코딩하시오:
			//sql 되는거 예문 아래에 복붙해두고 비교해서 작성하시고. (실무에선 혼남. 지울것)
//			select * from ps_board_free where b_no=4;
			String sql = String.format(
					"select * from %s"
					,Db.BOARD_2);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {				
				posts.add(new Dto(
						rs.getString("num"),
						rs.getString("title"),
						rs.getString("id"),
						rs.getString("dt"),
						rs.getString("hits"),
						rs.getString("content"),
						rs.getString("re_text"),
						rs.getString("re_count"),
						rs.getString("ori_num")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.close();
		return posts;
	}
	
	//업데이트
	public void edit(Dto d,String no) {
		super.connect();
			String sql = String.format(
					"update %s set title='%s',content='%s' where num=%s"
					,Db.BOARD_2, d.title,d.content,no);
			super.update(sql);
			super.close();
			
	}
	
}

