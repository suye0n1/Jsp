package com.db;

import java.io.IOException;
import java.util.ArrayList;

import com.jsp.board.BoardListProcessor;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//오류: server tomcat 에러 
//해결 방법:어노테이션과 web.xml을 함께 쓰면 충돌
@WebServlet("/board_2/*") // 경로 지정 /board/del, /board/list...
public class Controller extends HttpServlet {

	String category;
	String nextPage;
	Dao dao;
	Service service;

	@Override // init()함수: 초기화 작업(처음에만 실행)
	public void init() throws ServletException {
//		dao = new Dao();
		//처음에만 실행되는 함수로, doget함수에서도 사용 가능
		service = new Service();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		카테고리(2) category 불러오기 - index.jsp에 /board_2/list?category=free 행의 free를 불러와서 category에 저장
		category = request.getParameter("category");
		String action = request.getPathInfo(); // 해당 경로로 이동시켜줌 ex)/board/*에서 *을 del로 바꿔줌
		System.out.println("action:" + action);
		if (action != null) {
			switch (action) {
			case "/del":
				System.out.println("삭제");
				nextPage = "/board_2/list"; // list.jsp로 이동x nextPage에 저장
//				dao.del(request.getParameter("num"));
				service.del(category, request.getParameter("num"));
				break;
			case "/write":
//				3./list.jsp를 nextPage에 저장
				nextPage = "/board_2/list";
				// 4.write.jsp에서 작성한 내용을 가져와서 dto에 저장
//				dao.write(new Dto(	//이렇게 작성 가능
//								request.getParameter("title"),
//								request.getParameter("id"),
//								request.getParameter("content")
//						));
				Dto dto = new Dto(category, request.getParameter("title"), request.getParameter("id"),
						request.getParameter("content"));
//				dao.write(dto); // db에 저장
				service.write(dto); // db에 저장
				break;
			case "/read": // 5.list.jsp에서 제목 링크 클릭하면 /read 실행
				nextPage = "/read.jsp"; // 6.read.jsp를 nextPage에 저장
//				Dto d = dao.read(request.getParameter("num")); //7. ???
				Dto d = service.read(category, request.getParameter("num")); // 7. ???
				request.setAttribute("post", d); // 8.d에 저장된 내용을 post에 저장해서 내보내기
				break;
			// 9.read.jsp에서 수정 버튼을 누르면 /edit_insert로 이동
			case "/edit_insert":
				nextPage = "/edit.jsp"; // 10.edit.jsp를 nextPage에 저장
				// 11.dao.read를 통해 글 제목, 아이디, 내용을 post에 저장해서 내보내기
//				request.setAttribute("post", dao.read(request.getParameter("num")));
				request.setAttribute("post", service.read(category, request.getParameter("num")));
				break;
//				14.edit_proc 실행
			case "/edit_proc":
				nextPage = "/board_2/list";
				// 15.dao.edit 실행 (requset.getParameter를 통해 제목, 내용 가져오기)
//				dao.edit(new Dto(request.getParameter("title"), request.getParameter("content")),
//						request.getParameter("num"));
				service.edit(new Dto(request.getParameter("title"), request.getParameter("content")),
						request.getParameter("num"));
				break;
			case "/list":
				nextPage = "/list.jsp"; // list(2)nextPage에 저장
				// dao.list()안에 값을 page로 넘겨주면 null값이 들어감
				// index.jsp에서 "/board_2/list?page=1"를 안해줬기 때문에 값이 없음 그래서 dao.list는 Exception처리됨
				// 근데 페이지 작동이 잘된 이유는 posts=dao.list(pageNum);를 통해 값을 넘겨줬기 때문에...
//				ArrayList<Dto> posts = dao.list(); 
//				ArrayList<Dto> posts = service.list(); 

//				BoardListProcessor 클래스 만들고 
				// list(3)service.list로 이동 이때 currentPage는 null값
				// BoardListProcessor 타입 선언:BoardListProcessor클래스의 함수, 변수 등등 전부 사용 가능
				// list(5)service.list에서 blp값을 return하기 때문에
				// service.list(request.getParameter("currentPage"));가 blp값으로 바뀌고 좌변 blp에 저장
				// 2페이지로 이동해도 1페이지 리스트들이 나옴: request.getParameter의 괄호 안의 값을 currentPage로 해줬기 때문에
				// request.getParameter의 값은 page로 와야함
				// 3페이지일 경우 주소가 http://localhost:8080/board_2/list?page=3이기 때문에 page로 받아와야 값이
				// 들어감 currentPage로 쓰면 3페이지를 눌러도 null값이 나옴

				// 검색(1)word 객체 list로 보내기
				// 카테고리(3) category변수와 page, word 객체를 받아서 service.list로 이동
//				category(7) - service.list(request.getParameter("page"),request.getParameter("word"));가 blp값으로 바뀌고 blp(BoardListProcessor blp)에 저장
				BoardListProcessor blp = service.list(category, request.getParameter("page"),
						request.getParameter("word"));
				request.setAttribute("blp", blp); // list(6)blp값 내보내기 //category(8)-blp값 내보내기
				break;
			}
			// RequestDispatcher:
			// 서블릿에서 처리한 데이터를 jsp에서 가져다가 사용해야 할 때 쓰는 객체
			// RequestDispatcher는 이동할 경로를 설정하고 생성
			// 생성된 객체를 가지고 forward 메소드를 통해 해당 경로 페이지로 이동할 수 있음
			// 이때, sendRedirect와는 다르게 request와 response 객체를 가지고 이동할 수 있음
			// 호출된 페이지에서는 request.getAttribute() 메소드를 통해 넘겨받은 데이터를 처리할 수 있음
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, response); // forward ㅡ> read.jsp로 이동시켜줌

		}

	}
}
