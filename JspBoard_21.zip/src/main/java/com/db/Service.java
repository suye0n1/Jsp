package com.db;

import com.jsp.board.BoardListProcessor;

public class Service{
	Dao dao;
	
	public Service() {
		dao = new Dao();
	}
	public void del(String category, String no) {
		dao.del(category, no);
	}
	public void write(Dto d) {
		dao.write(d);
	}
	public Dto read(String category,String no) {
		return dao.selectPost(category, no);
	}
	//list(4)함수 실행
	
	//검색(2)매개변수 만들기-word
	public BoardListProcessor list(String category,String currentPage, String word){
		if(currentPage == null) {	//currentPage가 null이면
			currentPage = "1";	//1페이지가 나오도록
		}
		//새로운 객체 생성
		//BoardListProcessor클래스에서 dao에 저장된 값과 currentPage에 저장된 값을 저장
		//category(4) - BoardListProcessor로 이동
		//category(6) - blp에 저장 
		BoardListProcessor blp = new BoardListProcessor(dao, category, currentPage,word);
		return blp;
	}
	public void edit(Dto d, String no) {
		dao.update(d, no);
	}
}
