package com.db;

public class Page {

	public final static int PER_PAGE = 10;
	public final static int PAGE_BLOCK = 5;
	
}
